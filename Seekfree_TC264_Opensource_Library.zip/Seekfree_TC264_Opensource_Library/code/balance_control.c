/*
 * balance_control.c
 *
 *  Created on: 2025��4��18��
 *      Author: qing
 */
#include "balance_control.h"
cascade_value_struct balance_cascade;
cascade_value_struct  balance_cascade_resave;

float limit_value(float x,float y,float z)//�޷�
{
    if(x>z)x=z;
    if(x<y)x=y;
    return x;
}
//һ�׻����˲�
void first_order_complementray_filtering(cascade_common_value_struct*filter_value,int16 gyro_raw_data,int16 acc_raw_data)
{
    float gyro_temp;
    float acc_temp;
    gyro_temp=gyro_raw_data*filter_value->gyro_ration;
    acc_temp=(acc_raw_data-filter_value->angle_temp)*filter_value->acc_ration;
    filter_value->angle_temp+=((gyro_temp+acc_temp)*filter_value->call_cycle);
    filter_value->filtering_angle=filter_value->angle_temp+filter_value->machanical_zero;

}
//out=kp*error+ki*intererror+kd*(error-error_last) �ջ�λ��ʽpid
void pid_control(pid_cycle_struct*pid_cycle,float target,float actual)
{
    float   proportion_value=0;                                              //��������Ҳ���������
    float   different_value=0;                                               //΢����
    proportion_value=target-actual;
    pid_cycle->i_value+=(proportion_value*pid_cycle->i_value_pro);
    pid_cycle->i_value=limit_value(pid_cycle->i_value,-pid_cycle->i_value_max,pid_cycle->i_value_max);
    different_value=proportion_value-pid_cycle->p_value_last;
    pid_cycle->out=(int16)(pid_cycle->p*proportion_value+pid_cycle->i*pid_cycle->i_value+pid_cycle->d*different_value);
    pid_cycle->out=limit_value(pid_cycle->out,-pid_cycle->out_max,pid_cycle->out_max);
    pid_cycle->p_value_last=proportion_value;
}

void balance_cascade_init(void)
{

    balance_cascade.cascade_value.gyro_raw_data=&imu660ra_gyro_x;
    balance_cascade.cascade_value.acc_raw_data=&imu660ra_acc_y;
    balance_cascade.cascade_value.gyro_ration=4.0f;
    balance_cascade.cascade_value.acc_ration=4.0f;
    balance_cascade.cascade_value.call_cycle=0.005f;
    balance_cascade.cascade_value.machanical_zero=800;

    balance_cascade.cascade_value.filtering_angle=-balance_cascade.cascade_value.machanical_zero;
    balance_cascade.cascade_value.angle_temp=-balance_cascade.cascade_value.machanical_zero;


    balance_cascade.angular_speed_cycle.i_value_max=1000;
    balance_cascade.angular_speed_cycle.i_value_pro=0.1f;
    balance_cascade.angular_speed_cycle.out_max=10000;
    balance_cascade.angle_cycle.i_value_max=4000;
    balance_cascade.angle_cycle.i_value_pro=0.05f;
    balance_cascade.angle_cycle.out_max=8000;
    balance_cascade.speed_cycle.i_value_max=4000;
    balance_cascade.speed_cycle.i_value_pro=0.5f;
    balance_cascade.speed_cycle.out_max=1500;


    balance_cascade.angular_speed_cycle.p=1.0f;
    balance_cascade.angular_speed_cycle.i=0.0f;
    balance_cascade.angular_speed_cycle.d=0.0f;

    balance_cascade.angle_cycle.p=5.0f;
    balance_cascade.angle_cycle.i=0.0f;
    balance_cascade.angle_cycle.d=0.0f;

    balance_cascade.speed_cycle.p=10.0f;
    balance_cascade.speed_cycle.i=0.0f;
    balance_cascade.speed_cycle.d=0.0f;

}

