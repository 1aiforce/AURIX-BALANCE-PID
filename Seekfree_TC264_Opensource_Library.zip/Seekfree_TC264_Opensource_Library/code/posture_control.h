/*
 * posture_control.h
 *
 *  Created on: 2025��4��18��
 *      Author: qing
 */

#ifndef CODE_POSTURE_CONTROL_H_
#define CODE_POSTURE_CONTROL_H_

#include "zf_common_headfile.h"



void imu660ra_data_get(void);
void pit_isr_callback(void);
void dynamic_motor_control(void);
void dynamic_steer_control(void);

#endif /* CODE_POSTURE_CONTROL_H_ */
