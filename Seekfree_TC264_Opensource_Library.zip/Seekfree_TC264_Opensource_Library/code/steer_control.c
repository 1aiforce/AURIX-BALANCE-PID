/*
 * steer_control.c
 *
 *  Created on: 2025��4��20��
 *      Author: qing
 */
#include "steer_control.h"
steer_cascade_struct steer1;
steer_cascade_struct steer2;
steer_cascade_struct steer3;
steer_cascade_struct steer4;
void set_steer_duty(steer_cascade_struct*steer_value,int16 duty)
{
    steer_value->now_location=limit_value( steer_value->now_location,-10000,10000);
    pwm_set_duty( steer_value->pwm_pin,duty);

}
void steer_control(steer_cascade_struct*steer_value,int16 move_num)
{
    steer_value->now_location=steer_value->now_location+(steer_value->dir==1? move_num:-move_num);
    steer_value->now_location=limit_value( steer_value->now_location,-10000,10000);
    pwm_set_duty( steer_value->pwm_pin,steer_value->now_location);
}
void steer_cascade_init(void)
{
    steer1.pwm_pin=steer_1_pwm;
    steer1.control_fre=steer_1_fre;
    steer1.dir=steer_1_dir;
    steer1.center=steer_1_center;

    steer2.pwm_pin=steer_2_pwm;
    steer2.control_fre=steer_2_fre;
    steer2.dir=steer_2_dir;
    steer2.center=steer_2_center;


    steer3.pwm_pin=steer_3_pwm;
    steer3.control_fre=steer_3_fre;
    steer3.dir=steer_3_dir;
    steer3.center=steer_3_center;


    steer4.pwm_pin=steer_4_pwm;
    steer4.control_fre=steer_4_fre;
    steer4.dir=steer_4_dir;
    steer4.center=steer_4_center;

    steer1.center=steer1.center-1000*steer1.dir;
    steer2.center=steer2.center-1000*steer2.dir;
    steer3.center=steer3.center-1000*steer3.dir;
    steer4.center=steer4.center-1000*steer4.dir;

    steer1.now_location=steer1.center;
    steer2.now_location=steer2.center;
    steer3.now_location=steer3.center;
    steer4.now_location=steer4.center;



    pwm_init(steer1.pwm_pin,steer1.control_fre, steer1.now_location);
    pwm_init(steer2.pwm_pin,steer2.control_fre, steer2.now_location);
    pwm_init(steer3.pwm_pin,steer3.control_fre, steer3.now_location);
    pwm_init(steer4.pwm_pin,steer4.control_fre, steer4.now_location);


}
