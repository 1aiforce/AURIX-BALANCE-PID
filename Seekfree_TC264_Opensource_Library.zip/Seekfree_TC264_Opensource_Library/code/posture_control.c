/*
 * posture_control.c
 *
 *  Created on: 2025��4��18��
 *      Author: qing
 */
#include "posture_control.h"

#define fun_absc(x)   ((x)<0?-(x):(x))      //����ֵ����

void dynamic_motor_control(void)
{
    int16 left_duty;
    int16 right_duty;
    if(run_flag)
    {
        if(fun_absc(balance_cascade.cascade_value.filtering_angle)>2000)//�㵹����
        {
            run_flag=0;
        }
        left_duty=limit_value(balance_cascade.angular_speed_cycle.out,-10000,10000);
        right_duty=limit_value(balance_cascade.angular_speed_cycle.out,-10000,10000);
        small_driver_set_duty( left_duty, right_duty);
    }
    else
    {
        small_driver_set_duty(0,0);

    }
}
void dynamic_steer_control(void)
{
    int16 steer_output_duty=0;
    int16 steer_location_offset[4]={0};
    int16 target_location_offest[4]={0};

   static float steer_balance_angle=0;
   static float steer_out_duty_filter=0;
   steer_output_duty=limit_value(steer_output_duty/7,-350,350)*6;   //-��-��
   steer_out_duty_filter=19/20.0f* steer_out_duty_filter+0.05*steer_output_duty;

   if(jump_flag==0)
   {
       steer_balance_angle=limit_value(balance_cascade.angle_cycle.out,-350,350)*6;
   }
   else
       steer_balance_angle=0;


   steer_location_offset[0]=(steer1.now_location-steer1.center)*steer1.dir;
   steer_location_offset[1]=(steer2.now_location-steer2.center)*steer2.dir;
   steer_location_offset[2]=(steer3.now_location-steer3.center)*steer3.dir;
   steer_location_offset[3]=(steer4.now_location-steer4.center)*steer4.dir;

   target_location_offest[0]=steer_out_duty_filter-(steer_balance_angle>0?0 : steer_balance_angle);
   target_location_offest[1]=steer_out_duty_filter-(steer_balance_angle>0?0 : steer_balance_angle);
   target_location_offest[2]=steer_out_duty_filter+(steer_balance_angle>0?0 : steer_balance_angle);
   target_location_offest[3]=steer_out_duty_filter+(steer_balance_angle>0?0 : steer_balance_angle);

   if(run_flag)
   {
       if(!jump_flag)
       {
           steer_control(&steer1,limit_value(target_location_offest[0]-steer_location_offset[0],-10,10));
           steer_control(&steer2,limit_value(target_location_offest[1]-steer_location_offset[1],-10,10));
           steer_control(&steer3,limit_value(target_location_offest[2]-steer_location_offset[2],-10,10));
           steer_control(&steer4,limit_value(target_location_offest[3]-steer_location_offset[3],-10,10));
       }
       else
       {
           steer_control(&steer1,limit_value(steer1.center-steer1.now_location,-1,1)*steer_1_dir);
           steer_control(&steer2,limit_value(steer2.center-steer2.now_location,-1,1)*steer_2_dir);
           steer_control(&steer3,limit_value(steer3.center-steer3.now_location,-1,1)*steer_3_dir);
           steer_control(&steer4,limit_value(steer4.center-steer4.now_location,-1,1)*steer_4_dir);
       }
   }
}
void imu660ra_data_get(void)
{
    imu660ra_get_gyro();
    imu660ra_get_acc();
    imu660ra_gyro_y=imu660ra_gyro_y-8;

     if(fun_absc(imu660ra_gyro_x)<=5)
     {

       imu660ra_gyro_x=0;
      }
     if(imu660ra_gyro_x>5)
     {
        imu660ra_gyro_x-=5;
    }
    else if(imu660ra_gyro_x<-5)
     {
        imu660ra_gyro_x+=5;

     }
     if(fun_absc(imu660ra_gyro_y)<=5)
         {

             imu660ra_gyro_y=0;
         }
     if(imu660ra_gyro_y>5)
         {
             imu660ra_gyro_y-=5;
         }
         else if(imu660ra_gyro_y<-5)
         {
             imu660ra_gyro_y+=5;

         }
     if(fun_absc(imu660ra_gyro_z)<=5)
        {
             imu660ra_gyro_z=0;
         }
     if(imu660ra_gyro_z>5)
         {
             imu660ra_gyro_z-=5;
         }
         else if(imu660ra_gyro_z<-5)
         {
             imu660ra_gyro_z+=5;

         }
}
void pit_isr_callback(void)
{
    imu660ra_data_get();
    system_count++;
    if(system_count%20==0)
    {
     car_speed=(motor_value.receive_left_speed_data+motor_value.receive_right_speed_data)/2;
     pid_control(&balance_cascade.speed_cycle,0,car_speed);                                        //�ٶȻ�
    }
    if(system_count%5==0)
    {
    first_order_complementray_filtering(&balance_cascade.cascade_value,*balance_cascade.cascade_value.gyro_raw_data,*balance_cascade.cascade_value.acc_raw_data);
    pid_control(&balance_cascade.angle_cycle,balance_cascade.speed_cycle.out,balance_cascade.cascade_value.filtering_angle);     //�ǶȻ�
    }
   pid_control(&balance_cascade.angular_speed_cycle,balance_cascade.angle_cycle.out,*balance_cascade.cascade_value.gyro_raw_data);//balance_cascade.angle_cycle.out  ���ٶȻ�λ��ʽ
   dynamic_motor_control();
  // dynamic_steer_control();
}
