/*
 * user_values.h
 *
 *  Created on: 2025��4��18��
 *      Author: qing
 */

#ifndef CODE_USER_VALUES_H_
#define CODE_USER_VALUES_H_
#include "zf_common_headfile.h"


extern uint32 system_count      ;
extern uint8_t run_flag         ;
extern uint8_t jump_flag        ;
extern uint32_t jump_time       ;
extern int16 car_speed          ;


#endif /* CODE_USER_VALUES_H_ */
